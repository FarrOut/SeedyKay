import aws_encryption_sdk

def handler(event, context):
    print("test")
